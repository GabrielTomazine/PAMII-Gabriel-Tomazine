import Cont from './components/Contador';

export default function App() {
  return (    
    <Cont />    
  );
}
